![FluentTyper logo](public/icon/LogoFluentTyperWhite.jpg)

# FluentTyper

Type less, do more. FluentTyper brings smart autocomplete, spell checking, and text expansion to text inputs across the web.

[![CI (lint, unit, e2e)](https://github.com/bartekplus/FluentTyper/actions/workflows/test.yml/badge.svg)](https://github.com/bartekplus/FluentTyper/actions/workflows/test.yml)
[![CodeQL](https://github.com/bartekplus/FluentTyper/actions/workflows/codeql-analysis.yml/badge.svg)](https://github.com/bartekplus/FluentTyper/actions/workflows/codeql-analysis.yml)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-Support-FFDD00?logo=buymeacoffee&logoColor=000000)](https://www.buymeacoffee.com/FluentTyper)

## Quick Links

- Install: [Chrome](https://chrome.google.com/webstore/detail/fluenttyper-autocomplete/mbjlobpodpimgbkmlmjiblnmfgajmebm), [Firefox](https://addons.mozilla.org/en-US/firefox/addon/fluenttyper/), [Edge](https://microsoftedge.microsoft.com/addons/detail/fluenttyper-autocomplete/ljenfpihmhkddgmjoipinkhflinoofcn)
- Report a bug: [GitHub issue form](https://github.com/bartekplus/FluentTyper/issues/new/choose)
- Request a feature: [Feature request form](https://github.com/bartekplus/FluentTyper/issues/new?template=feature_request.yml)
- Contributing: [CONTRIBUTING.md](CONTRIBUTING.md)
- Security policy: [SECURITY.md](SECURITY.md)
- Sponsor development: [Buy Me a Coffee](https://www.buymeacoffee.com/FluentTyper)

## Why FluentTyper

FluentTyper helps you write faster and with fewer mistakes:

- Predictive autocomplete while typing
- Local prediction with libPresage (WebLLM path is currently dev/debug-only)
- Spelling suggestions
- Offline [measurement-unit spacing](docs/measurement-formatting.md) in verified prose contexts
- Offline [Review text](docs/review-mode.md): proofread a field you already wrote, with categorized highlights, one-click fixes and "Fix all safe" (`Alt+Shift+R`)
- Text expansion snippets for repeated phrases
- Keyboard-first suggestion selection with arrow keys and `Tab`

Example: type `callMe` and expand it to `Call me back once you're free`.

## Supported Languages

- English
- Spanish
- French
- Croatian
- Greek
- Swedish
- Polish
- German
- Brazilian Portuguese
- Arabic

## Installation

- [Chrome](https://chrome.google.com/webstore/detail/fluenttyper-autocomplete/mbjlobpodpimgbkmlmjiblnmfgajmebm)
- [Firefox](https://addons.mozilla.org/en-US/firefox/addon/fluenttyper/)
- [Edge](https://microsoftedge.microsoft.com/addons/detail/fluenttyper-autocomplete/ljenfpihmhkddgmjoipinkhflinoofcn)

## Quick Start

1. Install FluentTyper from your browser store.
2. Click any regular text input field on a website.
3. Start typing to see suggestions.
4. Use arrow keys to choose a suggestion.
5. Press `Tab` to accept, or `Esc` to dismiss.
6. To proofread text you already wrote, press `Alt+Shift+R`, click the **Review** button in the corner of the text box, or choose **Review text** in the popup.

## Site Profiles and Precedence

FluentTyper applies configuration in this order:

1. Global enable switch (`Enable Extension`) must be on.
2. Domain allow/block mode decides if FluentTyper runs on the current site.
3. If a site profile exists for the current domain, it overrides config values:
   - `language`: always overridden by the profile value.
   - `inline_suggestion`: overridden only when set in the profile; otherwise inherited from global.
   - `numSuggestions`: overridden only when set in the profile; otherwise inherited from global.

Site profiles never bypass domain enable/disable logic. If a domain is blocked by allow/block mode, FluentTyper remains disabled there even if a profile exists.

## Compatibility

FluentTyper works on most websites, including Google Docs.

Google Docs support activates on any document edit page when FluentTyper is enabled for docs.google.com. Suggestions are applied through a single synthetic plain-text paste into the editor, and the edit is verified against the document model before local learning records it. See [docs/google-docs-integration.md](docs/google-docs-integration.md) for details and limits. Other canvas-based rich text editors can still be partially or fully incompatible.

If you hit an unsupported site, please open a bug report so compatibility can be improved.

## AI Predictor (WebLLM, Dev/Debug Only)

WebLLM is currently available only in development/debug builds.

- Production store builds (Chrome, Firefox, Edge) currently run libPresage-only.
- The AI predictor toggle is not exposed to end users in production builds.
- In dev/debug builds, WebLLM can run in parallel with Presage and falls back automatically when unavailable.
- In dev/debug builds, first AI use downloads model artifacts once; subsequent runs use browser cache.

## Privacy

FluentTyper is privacy-first:

- No upload of your typed content
- Works offline
- Predictions are generated locally on your computer
- Review text checks the field in the page itself; the reviewed text is never uploaded, logged or stored
- In dev/debug builds, when AI predictor is enabled, only model artifacts are downloaded; typed content stays local

## Development Setup

FluentTyper uses [Bun](https://bun.sh/) as the primary package manager and script runner.

### Prerequisites

- [Bun](https://bun.sh/) `1.4.2` (pinned in `packageManager`)

### Install and Build

```bash
bun install
bun run build
bun run build --platform=firefox
```

### Quality Checks

```bash
bun run check          # lint + format + typecheck
bun run lint           # Oxlint with TypeScript-aware rules
bun run typecheck      # TypeScript 7 only
bun run format:check   # Prettier only
```

### Testing

```bash
bun test               # unit tests
bun run test:e2e       # e2e smoke (Chrome)
bun run test:e2e:full  # full regression (Chrome + Firefox)
```

### Development Watch

```bash
bun run watch          # rebuilds on file changes (dev mode)
```

Migration note: `bun.lock` is the source of truth for reproducible installs. npm/pnpm are no longer required for normal development workflows.

## Architecture

FluentTyper follows a strict layered clean architecture:

```
src/
  core/
    domain/        # Pure business logic, contracts, types
    application/   # Use-case orchestration, repositories
  adapters/
    chrome/
      background/  # Service worker, prediction engines
      content-script/ # DOM interaction, suggestion UI
  ui/
    options/       # Settings pages
    popup/         # Extension popup
    onboarding/    # First-run experience
```

Layer boundaries are enforced by Oxlint `no-restricted-imports` rules. See [docs/agents/architecture.md](docs/agents/architecture.md) for details.

## Bug Reporting

Please report bugs through GitHub Issues using the bug template:

- Issue chooser: [github.com/bartekplus/FluentTyper/issues/new/choose](https://github.com/bartekplus/FluentTyper/issues/new/choose)
- Direct bug report form: [bug_report.yml](https://github.com/bartekplus/FluentTyper/issues/new?template=bug_report.yml)

To speed up triage, include:

- Steps to reproduce
- Expected behavior
- Actual behavior
- Browser and FluentTyper version
- Screenshots or recordings when possible

## Feature Requests

Use the feature request form to propose improvements:

- Issue chooser: [github.com/bartekplus/FluentTyper/issues/new/choose](https://github.com/bartekplus/FluentTyper/issues/new/choose)
- Direct feature form: [feature_request.yml](https://github.com/bartekplus/FluentTyper/issues/new?template=feature_request.yml)

Good feature requests include:

- The problem you want to solve
- The proposed solution
- Alternatives you considered
- Browser context and examples or mockups

## Security

If you discovered a security vulnerability, follow [SECURITY.md](SECURITY.md) and avoid opening a public issue.

## Contributing

Development and contribution guidelines are in [CONTRIBUTING.md](CONTRIBUTING.md).

## Sponsorship and Support

If FluentTyper saves you time, you can support maintenance and future development:

[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-Donate-FFDD00?logo=buymeacoffee&logoColor=000000)](https://www.buymeacoffee.com/FluentTyper)

## License

[MIT](LICENSE) - Copyright (c) 2026 Bartosz Tomczyk
